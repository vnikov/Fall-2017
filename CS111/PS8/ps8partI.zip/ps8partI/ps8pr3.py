#
# ps8pr3.py  (Problem Set 8, Problem 3)
#
# Conway's Game of Life
#
# Computer Science 111  
#

# IMPORTANT: this file is for your solutions to Problem 3.
# Your solutions to Problem 2 should go in ps8pr2.py instead.

from ps8pr2 import *
from gol_graphics import *
import random

# a function that may be useful when testing your other functions
def random_grid(height, width):
    """ creates and returns a height x width grid in which the inner cells
        are randomly set to 0 or 1, and cells on the outer border are all 0.
        inputs: height and width are positive integers
    """
    grid = create_grid(height, width)   # initially all 0s
 
    for r in range(1, height - 1):
        for c in range(1, width - 1):
            grid[r][c] = random.choice([0, 1])
            
    return grid
